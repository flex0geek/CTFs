#!/bin/sh

qemu-aarch64 pacsh
